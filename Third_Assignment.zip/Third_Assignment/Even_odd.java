//5.Write a program to check whether a number is even or odd?
package Third_Assignment;

public class Even_odd {

	public static void main(String[] args) {
		int a=11;
		String num;
		if(a%2==0) {
			num="even";
		}
		else {
			num="odd";
		}
		System.out.println("the given numberis :"+num);

	}

}
