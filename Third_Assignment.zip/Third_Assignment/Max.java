//1.Write a program to find maximum between two numbers?
package Third_Assignment;

public class Max {
	public static void main(String[]args) {
		int a=1, b=2;
		int max;
		if (a>b) {
			max=a;
		}
		else {
			max=b;
		}
		System.out.println(max);
		
	}
	
}

