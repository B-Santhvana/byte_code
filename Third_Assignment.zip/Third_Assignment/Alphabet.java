//7.Write a program to check whether a character is alphabet or not?
package Third_Assignment;

public class Alphabet {

	public static void main(String[] args) {
		char letter = '5';
		if ((letter>'a')||(letter>'A')) {
			System.out.println("alphabet");
		}
		else {
			System.out.println("not an alphabet");
		}

}
}