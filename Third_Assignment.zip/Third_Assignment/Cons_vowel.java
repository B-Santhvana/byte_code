//8.Write a program to input any alphabet and check whether it is vowel or consonant?
package Third_Assignment;

public class Cons_vowel {

	public static void main(String[] args) {
		char letter='s';
		if (letter=='a'||letter=='e'||letter=='i'||letter=='o'||letter=='u'||letter=='A'||letter=='E'||letter=='I'||letter=='O'||letter=='U') {
			System.out.println("given letter is a vowel");
			
		}
		else {
			System.out.println("given letter is a consonent");
		}

	}

}
