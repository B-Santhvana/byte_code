//23.Sum All Three Angles and Check Equal or Not in Java?
package Third_Assignment;

public class Equal_check {

	public static void main(String[] args) {
		int angle1=60, angle2=60 , angle3=60;
		if (angle1+angle2+angle3==180) {
			System.out.println("equal");
		}
		else {
			System.out.println("not equal");
		}

	}

}
