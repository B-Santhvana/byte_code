//5)Write a Java program that takes five numbers as input to calculate and print the average of the numbers
package second_assignment;
//import java.io.*;
public class Average {

	public static void main(String[] args) {
		int a=1, b=2, c=3, d=4, e=5;
		int total= a+b+c+d+e;//15
		System.out.println("average:"+ total/5);//3

	}

}
