//4)Write a Java program to print the sum, multiply, subtract, divide and remainder of two numbers
package second_assignment;
//import java.io.*;
public class math_op {

	public static void main(String[] args) {
		int a=1, b=2;
		System.out.println("addition of a and b:"+(a+b));//3
		System.out.println("subtraction of a and b:"+(a-b));//-1
		System.out.println("multiplication of a and b:"+(a*b));//2
		System.out.println("division of a and b:"+(a/b));//0
		System.out.println("remainder of a and b:"+(a%b));//1
	}

}
