//Write a program to calculate the perimeter of a triangle having sides of length 2,3 and 5 units.
package firstAssignment;

public class tri_perimeter {

	public static void main(String[] args) {
		int s1=2,s2=3,s3=5;
		System.out.println("perimeter of triangle :"+(s1+s2+s3));//10

	}

}
