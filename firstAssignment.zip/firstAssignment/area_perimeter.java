///Length and breadth of a rectangle are 5 and 7 respectively. Write a program to calculate the area and perimeter of the rectangle.
package firstAssignment;

public class area_perimeter {

	public static void main(String[] args) {
		int length=5,breadth=7;
		System.out.println("area of rectangle="+(length*breadth));//35
		System.out.println("perimeter of rectangle="+(2*(length+breadth)));//24

	}

}
