//Write a program to check if the two numbers 23 and 45 are equal.
package firstAssignment;

public class comparision {

	public static void main(String[] args) {
		int a=23,b=45;
		System.out.println("a and b are equal:"+(a==b));

	}

}
